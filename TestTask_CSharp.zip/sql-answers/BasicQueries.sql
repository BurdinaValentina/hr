/*
    SQL — базовые знания: ответы в виде запросов.
    Запросы проверены на SQL Server 2025 (LocalDB).
*/

/* ---------- select … join ---------- */

-- 1. Все поля обеих таблиц, только записи с совпадающим ID
SELECT T1.*, T2.*
FROM T1
INNER JOIN T2 ON T2.ID = T1.ID;

-- 2. Все поля обеих таблиц: все записи из T1 и только совпавшие из T2
SELECT T1.*, T2.*
FROM T1
LEFT JOIN T2 ON T2.ID = T1.ID;

-- 3. Все записи из T1, для которых нет такого ID в T2
SELECT T1.*
FROM T1
WHERE NOT EXISTS (SELECT 1 FROM T2 WHERE T2.ID = T1.ID);

-- то же через LEFT JOIN
SELECT T1.*
FROM T1
LEFT JOIN T2 ON T2.ID = T1.ID
WHERE T2.ID IS NULL;


/* ---------- XML ---------- */

-- Данные из таблицы T в XML
SELECT Id, Code, Name, StatusId
FROM T
FOR XML PATH('row'), ROOT('data');

-- Выборка данных из XML предыдущего запроса + фильтр StatusId != 3
DECLARE @x xml = (
    SELECT Id, Code, Name, StatusId
    FROM T
    FOR XML PATH('row'), ROOT('data'), TYPE
);

SELECT
    r.value('(Id/text())[1]',       'int')           AS Id,
    r.value('(Code/text())[1]',     'varchar(50)')   AS Code,
    r.value('(Name/text())[1]',     'nvarchar(100)') AS Name,
    r.value('(StatusId/text())[1]', 'int')           AS StatusId
FROM @x.nodes('/data/row') AS n(r)
WHERE r.value('(StatusId/text())[1]', 'int') <> 3;

-- фильтр можно перенести прямо в XPath
SELECT r.value('(Id/text())[1]', 'int') AS Id
FROM @x.nodes('/data/row[StatusId != 3]') AS n(r);
