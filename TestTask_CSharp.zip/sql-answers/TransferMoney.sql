/*
    SQL — практическая задача: перевод суммы @S со счёта @N1 на счёт @N2
    с проверкой остатка и использованием транзакции.
*/

-- Таблица счетов (в задании — T: N — номер счёта, S — сумма на счёте)
IF OBJECT_ID(N'dbo.T', N'U') IS NULL
    CREATE TABLE dbo.T
    (
        N varchar(20)    NOT NULL CONSTRAINT PK_T PRIMARY KEY,
        S decimal(18, 2) NOT NULL CONSTRAINT CK_T_S CHECK (S >= 0)
    );
GO

CREATE OR ALTER PROCEDURE dbo.TransferMoney
    @N1 varchar(20),     -- номер первого счёта (списание)
    @N2 varchar(20),     -- номер второго счёта (зачисление)
    @S  decimal(18, 2)   -- сумма перевода
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;   -- при любой ошибке транзакция будет откачена целиком

    IF @S IS NULL OR @S <= 0
        THROW 50001, N'Сумма перевода должна быть больше нуля', 1;
    IF @N1 = @N2
        THROW 50002, N'Счёт списания и счёт зачисления совпадают', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Блокируем обе строки до конца транзакции (UPDLOCK + HOLDLOCK) одним запросом по ключу:
        -- между проверкой остатка и списанием никто не сможет изменить баланс,
        -- а встречные переводы A->B и B->A не поймают взаимоблокировку
        DECLARE @Found int, @Balance decimal(18, 2);

        SELECT @Found = COUNT(*)
        FROM dbo.T WITH (UPDLOCK, HOLDLOCK)
        WHERE N IN (@N1, @N2);

        IF @Found < 2
            THROW 50003, N'Один из счетов не найден', 1;

        SELECT @Balance = S FROM dbo.T WHERE N = @N1;

        IF @Balance < @S
            THROW 50004, N'Недостаточно средств на счёте списания', 1;

        UPDATE dbo.T SET S = S - @S WHERE N = @N1;
        UPDATE dbo.T SET S = S + @S WHERE N = @N2;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;   -- откатываем обе операции: деньги не «теряются» и не «появляются»
        THROW;                      -- пробрасываем исходную ошибку вызывающему коду
    END CATCH
END
GO

/* ---------- Демонстрация работы транзакции ---------- */
DELETE dbo.T;
INSERT dbo.T (N, S) VALUES ('40817810000000000001', 1000.00), ('40817810000000000002', 500.00);

-- 1. Успешный перевод: 1000/500 -> 700/800
EXEC dbo.TransferMoney @N1 = '40817810000000000001', @N2 = '40817810000000000002', @S = 300;
SELECT * FROM dbo.T;
GO
-- 2. Недостаточно средств: ошибка 50004, балансы не изменились (700/800)
EXEC dbo.TransferMoney @N1 = '40817810000000000001', @N2 = '40817810000000000002', @S = 5000;
GO
SELECT * FROM dbo.T;
GO
-- 3. Несуществующий счёт получателя: ошибка 50003, списания со счёта 1 не произошло (700/800)
EXEC dbo.TransferMoney @N1 = '40817810000000000001', @N2 = '99999999999999999999', @S = 100;
GO
SELECT * FROM dbo.T;
GO
