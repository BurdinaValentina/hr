namespace HomeLibrary.Web.Models;

/// <summary>Где искать строку запроса.</summary>
public enum SearchScope
{
    All,
    Title,
    Author,
    TableOfContents,
}

public sealed record BookSearchFilter(string? Query, SearchScope Scope = SearchScope.All)
{
    public bool InTitle => Scope is SearchScope.All or SearchScope.Title;
    public bool InAuthor => Scope is SearchScope.All or SearchScope.Author;
    public bool InToc => Scope is SearchScope.All or SearchScope.TableOfContents;
}
