namespace HomeLibrary.Web.Models;

/// <summary>Строка списка книг (результат dbo.Book_Search).</summary>
public sealed class BookListItem
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Author { get; set; } = "";
    public short? PublishYear { get; set; }
    public string? Genre { get; set; }
    public string? Location { get; set; }
    public bool HasToc { get; set; }
}
