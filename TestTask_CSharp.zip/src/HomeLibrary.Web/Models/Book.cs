namespace HomeLibrary.Web.Models;

/// <summary>Книга в том виде, в каком она хранится в БД.</summary>
public sealed class Book
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Author { get; set; } = "";
    public short? PublishYear { get; set; }
    public string? Publisher { get; set; }
    public string? Isbn { get; set; }
    public string? Genre { get; set; }
    public int? PageCount { get; set; }
    public string? Location { get; set; }
    public string? Notes { get; set; }

    /// <summary>Оглавление — XML вида &lt;toc&gt;…XHTML…&lt;/toc&gt;.</summary>
    public string? TableOfContents { get; set; }

    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    /// <summary>Версия строки для оптимистичной блокировки.</summary>
    public byte[] RowVer { get; set; } = [];
}
