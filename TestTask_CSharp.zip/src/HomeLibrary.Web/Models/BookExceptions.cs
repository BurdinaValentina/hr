namespace HomeLibrary.Web.Models;

public sealed class BookNotFoundException(int id)
    : Exception($"Книга с Id = {id} не найдена")
{
    public int BookId { get; } = id;
}

/// <summary>Книгу успели изменить между открытием карточки и сохранением.</summary>
public sealed class BookConcurrencyException(string message) : Exception(message);
