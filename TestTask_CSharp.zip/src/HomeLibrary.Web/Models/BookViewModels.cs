using System.ComponentModel.DataAnnotations;

namespace HomeLibrary.Web.Models;

public sealed class BookListViewModel
{
    public string? Query { get; init; }
    public SearchScope Scope { get; init; }
    public IReadOnlyList<BookListItem> Books { get; init; } = [];
}

/// <summary>Карточка книги в режиме создания/редактирования.</summary>
public sealed class BookEditViewModel
{
    public int Id { get; set; }

    [Display(Name = "Название")]
    [Required(ErrorMessage = "Укажите название")]
    [StringLength(300)]
    public string Title { get; set; } = "";

    [Display(Name = "Автор")]
    [Required(ErrorMessage = "Укажите автора")]
    [StringLength(300)]
    public string Author { get; set; } = "";

    [Display(Name = "Год издания")]
    [Range(1400, 2100, ErrorMessage = "Год издания должен быть в диапазоне {1}–{2}")]
    public short? PublishYear { get; set; }

    [Display(Name = "Издательство")]
    [StringLength(200)]
    public string? Publisher { get; set; }

    [Display(Name = "ISBN")]
    [StringLength(17)]
    [RegularExpression(@"^[0-9Xx\-]{10,17}$", ErrorMessage = "ISBN: 10–13 цифр, допускаются дефисы и X")]
    public string? Isbn { get; set; }

    [Display(Name = "Жанр")]
    [StringLength(100)]
    public string? Genre { get; set; }

    [Display(Name = "Страниц")]
    [Range(1, 100_000, ErrorMessage = "Количество страниц должно быть положительным")]
    public int? PageCount { get; set; }

    [Display(Name = "Где стоит")]
    [StringLength(100)]
    public string? Location { get; set; }

    [Display(Name = "Заметки")]
    [StringLength(2000)]
    public string? Notes { get; set; }

    /// <summary>HTML из редактора оглавления; в БД сохраняется как XML.</summary>
    [Display(Name = "Оглавление")]
    public string? TableOfContentsHtml { get; set; }

    /// <summary>Версия строки (base64) — для контроля параллельных правок.</summary>
    public string? RowVersion { get; set; }

    public bool IsNew => Id == 0;

    public static BookEditViewModel FromBook(Book book, string tocHtml) => new()
    {
        Id = book.Id,
        Title = book.Title,
        Author = book.Author,
        PublishYear = book.PublishYear,
        Publisher = book.Publisher,
        Isbn = book.Isbn,
        Genre = book.Genre,
        PageCount = book.PageCount,
        Location = book.Location,
        Notes = book.Notes,
        TableOfContentsHtml = tocHtml,
        RowVersion = Convert.ToBase64String(book.RowVer),
    };

    public Book ToBook(string? tocXml) => new()
    {
        Id = Id,
        Title = Title.Trim(),
        Author = Author.Trim(),
        PublishYear = PublishYear,
        Publisher = Normalize(Publisher),
        Isbn = Normalize(Isbn),
        Genre = Normalize(Genre),
        PageCount = PageCount,
        Location = Normalize(Location),
        Notes = Normalize(Notes),
        TableOfContents = tocXml,
        RowVer = string.IsNullOrEmpty(RowVersion) ? [] : Convert.FromBase64String(RowVersion),
    };

    private static string? Normalize(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}

public sealed class BookDetailsViewModel
{
    public required Book Book { get; init; }
    public required string TableOfContentsHtml { get; init; }
}
