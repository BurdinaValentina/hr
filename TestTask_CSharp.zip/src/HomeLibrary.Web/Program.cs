using HomeLibrary.Web.Data;
using HomeLibrary.Web.Infrastructure;
using HomeLibrary.Web.Services;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews(options =>
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()));

builder.Services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();
builder.Services.AddScoped<IBookRepository, BookRepository>();
builder.Services.AddSingleton<TocXmlConverter>();
builder.Services.AddSingleton<DatabaseInitializer>();
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();

var app = builder.Build();

if (app.Configuration.GetValue<bool>("Database:InitializeOnStartup"))
    await app.Services.GetRequiredService<DatabaseInitializer>().InitializeAsync();

app.UseExceptionHandler("/Error");
app.UseStatusCodePagesWithReExecute("/Error/{0}");

if (!app.Environment.IsDevelopment())
    app.UseHsts();

app.UseRouting();
app.MapStaticAssets();

app.MapControllerRoute(
        name: "default",
        pattern: "{controller=Books}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();
