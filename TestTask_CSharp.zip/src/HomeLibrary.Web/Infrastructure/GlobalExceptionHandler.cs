using Microsoft.AspNetCore.Diagnostics;

namespace HomeLibrary.Web.Infrastructure;

/// <summary>
/// Глобальный обработчик исключений: логирует ошибку с TraceId
/// и отдаёт управление дальше — страницу ошибки покажет ErrorController.
/// </summary>
public sealed class GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    public ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken ct)
    {
        logger.LogError(exception, "Необработанная ошибка при запросе {Method} {Path}. TraceId: {TraceId}",
            httpContext.Request.Method, httpContext.Request.Path, httpContext.TraceIdentifier);

        // false — ответ не сформирован, UseExceptionHandler выполнит re-execute на /Error
        return ValueTask.FromResult(false);
    }
}
