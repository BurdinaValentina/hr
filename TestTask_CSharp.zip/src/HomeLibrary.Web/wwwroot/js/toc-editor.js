// HTML-редактор оглавления (Quill) + импорт оглавления из XML-файла.
(() => {
    const form = document.getElementById('book-form');
    const hidden = document.getElementById('toc-html');
    const fileInput = document.getElementById('toc-file');
    const importError = document.getElementById('toc-import-error');

    const quill = new Quill('#toc-editor', {
        theme: 'snow',
        placeholder: 'Части, главы, разделы…',
        // Только те форматы, которые переживут серверную очистку в TocXmlConverter
        formats: ['header', 'bold', 'italic', 'underline', 'strike', 'script', 'blockquote', 'list', 'indent'],
        modules: {
            toolbar: [
                [{ header: [2, 3, 4, false] }],
                ['bold', 'italic', 'underline', 'strike'],
                [{ list: 'ordered' }, { list: 'bullet' }, { indent: '-1' }, { indent: '+1' }],
                ['blockquote', 'clean'],
            ],
        },
    });

    // Исходное содержимое берём из скрытого поля: так браузер не исполняет разметку до её разбора Quill
    if (hidden.value) {
        quill.clipboard.dangerouslyPasteHTML(hidden.value, 'silent');
    }

    form.addEventListener('submit', () => {
        // getSemanticHTML отдаёт «нормальные» вложенные <ol>/<ul>, а не внутренний формат Quill
        hidden.value = quill.getLength() > 1 ? quill.getSemanticHTML() : '';
    });

    fileInput.addEventListener('change', async () => {
        const file = fileInput.files[0];
        if (!file) return;

        importError.classList.add('d-none');
        const data = new FormData();
        data.append('file', file);
        data.append('__RequestVerificationToken', form.querySelector('input[name="__RequestVerificationToken"]').value);

        try {
            const response = await fetch(fileInput.dataset.importUrl, { method: 'POST', body: data });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error ?? 'Не удалось загрузить файл');

            quill.setContents([]);
            quill.clipboard.dangerouslyPasteHTML(result.html, 'user');
        } catch (e) {
            importError.textContent = e.message;
            importError.classList.remove('d-none');
        } finally {
            fileInput.value = '';
        }
    });
})();
