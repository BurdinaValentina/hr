using System.Text;
using HomeLibrary.Web.Data;
using HomeLibrary.Web.Models;
using HomeLibrary.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace HomeLibrary.Web.Controllers;

public sealed class BooksController(IBookRepository books, TocXmlConverter toc) : Controller
{
    private const long MaxTocFileSize = 1024 * 1024;

    // GET /Books?query=...&scope=...
    public async Task<IActionResult> Index(string? query, SearchScope scope, CancellationToken ct)
    {
        var items = await books.SearchAsync(new BookSearchFilter(query, scope), ct);
        return View(new BookListViewModel { Query = query, Scope = scope, Books = items });
    }

    // GET /Books/Details/5 — карточка в режиме просмотра
    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var book = await books.GetByIdAsync(id, ct);
        if (book is null)
            return NotFound();

        return View(new BookDetailsViewModel { Book = book, TableOfContentsHtml = toc.XmlToHtml(book.TableOfContents) });
    }

    public IActionResult Create() => View("Edit", new BookEditViewModel());

    [HttpPost]
    public async Task<IActionResult> Create(BookEditViewModel model, CancellationToken ct)
    {
        if (!TryConvertToc(model, out var tocXml))
            return View("Edit", model);

        var id = await books.InsertAsync(model.ToBook(tocXml), ct);
        TempData["Message"] = $"Книга «{model.Title}» добавлена";
        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> Edit(int id, CancellationToken ct)
    {
        var book = await books.GetByIdAsync(id, ct);
        if (book is null)
            return NotFound();

        return View(BookEditViewModel.FromBook(book, toc.XmlToHtml(book.TableOfContents)));
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, BookEditViewModel model, CancellationToken ct)
    {
        model.Id = id;
        if (!TryConvertToc(model, out var tocXml))
            return View(model);

        try
        {
            await books.UpdateAsync(model.ToBook(tocXml), ct);
        }
        catch (BookNotFoundException)
        {
            return NotFound();
        }
        catch (BookConcurrencyException ex)
        {
            ModelState.AddModelError("", ex.Message);
            return View(model);
        }

        TempData["Message"] = "Изменения сохранены";
        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        var book = await books.GetByIdAsync(id, ct);
        return book is null ? NotFound() : View(book);
    }

    [HttpPost, ActionName(nameof(Delete))]
    public async Task<IActionResult> DeleteConfirmed(int id, CancellationToken ct)
    {
        try
        {
            await books.DeleteAsync(id, ct);
        }
        catch (BookNotFoundException)
        {
            return NotFound();
        }

        TempData["Message"] = "Книга удалена";
        return RedirectToAction(nameof(Index));
    }

    // GET /Books/TocXml/5 — выгрузка оглавления в xml-файл
    public async Task<IActionResult> TocXml(int id, CancellationToken ct)
    {
        var book = await books.GetByIdAsync(id, ct);
        if (book is null)
            return NotFound();

        var content = toc.ToXmlFile(book.TableOfContents, book.Title, book.Author);
        return File(content, "application/xml; charset=utf-8", $"toc-{id}.xml");
    }

    // POST /Books/ImportToc — загрузка оглавления из xml-файла в редактор карточки
    [HttpPost]
    public async Task<IActionResult> ImportToc(IFormFile? file, CancellationToken ct)
    {
        if (file is null || file.Length == 0)
            return BadRequest(new { error = "Файл не выбран" });
        if (file.Length > MaxTocFileSize)
            return BadRequest(new { error = "Файл больше 1 МБ" });

        using var reader = new StreamReader(file.OpenReadStream(), Encoding.UTF8, detectEncodingFromByteOrderMarks: true);
        var content = await reader.ReadToEndAsync(ct);

        try
        {
            return Ok(new { html = toc.ImportXmlFile(content) });
        }
        catch (TocFormatException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    private bool TryConvertToc(BookEditViewModel model, out string? tocXml)
    {
        tocXml = null;
        if (!ModelState.IsValid)
            return false;

        try
        {
            tocXml = toc.HtmlToXml(model.TableOfContentsHtml);
            return true;
        }
        catch (System.Xml.XmlException ex)
        {
            ModelState.AddModelError(nameof(model.TableOfContentsHtml), $"Оглавление не удалось сохранить как XML: {ex.Message}");
            return false;
        }
    }
}
