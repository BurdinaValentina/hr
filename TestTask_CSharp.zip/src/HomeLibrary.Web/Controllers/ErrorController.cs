using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace HomeLibrary.Web.Controllers;

[ApiExplorerSettings(IgnoreApi = true)]
[IgnoreAntiforgeryToken]  // сюда же делается re-execute упавших POST-запросов
public sealed class ErrorController : Controller
{
    // Сюда приходят необработанные исключения (UseExceptionHandler)
    // и ответы с кодами ошибок без тела (UseStatusCodePagesWithReExecute)
    [Route("/Error/{statusCode:int?}")]
    public IActionResult Index(int? statusCode)
    {
        var code = statusCode ?? StatusCodes.Status500InternalServerError;
        Response.StatusCode = code;

        ViewData["StatusCode"] = code;
        ViewData["TraceId"] = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
        return View();
    }
}
