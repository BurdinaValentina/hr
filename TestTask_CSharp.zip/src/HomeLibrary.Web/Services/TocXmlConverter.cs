using System.Xml;
using System.Xml.Linq;
using AngleSharp.Xhtml;
using Ganss.Xss;

namespace HomeLibrary.Web.Services;

/// <summary>
/// Преобразует оглавление между HTML (что редактирует пользователь в HTML-редакторе)
/// и XML (что хранится в поле dbo.Book.TableOfContents и выгружается в файл).
/// Формат XML: &lt;toc&gt; + очищенный XHTML-фрагмент.
/// </summary>
public sealed class TocXmlConverter
{
    public const string RootName = "toc";

    private readonly HtmlSanitizer _sanitizer;

    public TocXmlConverter()
    {
        // Разрешаем только разметку, которая имеет смысл для оглавления — никаких script/style/on*.
        _sanitizer = new HtmlSanitizer(new HtmlSanitizerOptions
        {
            AllowedTags = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "h1", "h2", "h3", "h4", "h5", "h6", "p", "br", "ol", "ul", "li",
                "strong", "b", "em", "i", "u", "s", "sub", "sup", "blockquote",
            },
            AllowedAttributes = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "start" },
        });
        _sanitizer.OutputFormatter = XhtmlMarkupFormatter.Instance;  // на выходе — well-formed XHTML
    }

    /// <summary>HTML из редактора → XML для БД. Пустое оглавление → null.</summary>
    public string? HtmlToXml(string? html)
    {
        if (string.IsNullOrWhiteSpace(html))
            return null;

        var xhtml = _sanitizer.Sanitize(html);
        var root = XElement.Parse($"<{RootName}>{xhtml}</{RootName}>", LoadOptions.PreserveWhitespace);

        // Редакторы любят неразрывные пробелы (&nbsp;) — в оглавлении они мешают поиску
        foreach (var text in root.DescendantNodes().OfType<XText>())
            text.Value = text.Value.Replace(' ', ' ');

        // Редактор отдаёт "<p><br></p>" для пустого поля — такое оглавление не храним
        if (string.IsNullOrWhiteSpace(root.Value))
            return null;

        return root.ToString(SaveOptions.DisableFormatting);
    }

    /// <summary>XML из БД → HTML для редактора и карточки.</summary>
    public string XmlToHtml(string? xml)
    {
        if (string.IsNullOrWhiteSpace(xml))
            return "";

        var root = XElement.Parse(xml, LoadOptions.PreserveWhitespace);
        var inner = string.Concat(root.Nodes().Select(n => n.ToString(SaveOptions.DisableFormatting)));

        // Повторная очистка — защита на случай, если в БД попали данные в обход приложения
        return _sanitizer.Sanitize(inner);
    }

    /// <summary>Формирует содержимое .xml-файла с оглавлением для выгрузки.</summary>
    public byte[] ToXmlFile(string? xml, string title, string author)
    {
        var root = string.IsNullOrWhiteSpace(xml) ? new XElement(RootName) : XElement.Parse(xml);
        root.SetAttributeValue("title", title);
        root.SetAttributeValue("author", author);

        var document = new XDocument(new XDeclaration("1.0", "utf-8", null), root);

        using var stream = new MemoryStream();
        using (var writer = XmlWriter.Create(stream, new XmlWriterSettings
               {
                   Indent = true,
                   Encoding = new System.Text.UTF8Encoding(encoderShouldEmitUTF8Identifier: false),
               }))
        {
            document.Save(writer);
        }
        return stream.ToArray();
    }

    /// <summary>
    /// Разбирает загруженный .xml-файл оглавления и возвращает HTML для редактора.
    /// </summary>
    /// <exception cref="TocFormatException">Файл не является корректным оглавлением.</exception>
    public string ImportXmlFile(string content)
    {
        XElement root;
        try
        {
            // Без PreserveWhitespace: отбрасываем отступы, которыми отформатирован файл
            root = XElement.Parse(content);
        }
        catch (XmlException ex)
        {
            throw new TocFormatException($"Файл не является корректным XML: {ex.Message}");
        }

        if (root.Name.LocalName != RootName)
            throw new TocFormatException($"Корневой элемент должен быть <{RootName}>, а не <{root.Name.LocalName}>");

        root.RemoveAttributes();
        return XmlToHtml(root.ToString(SaveOptions.DisableFormatting));
    }
}

public sealed class TocFormatException(string message) : Exception(message);
