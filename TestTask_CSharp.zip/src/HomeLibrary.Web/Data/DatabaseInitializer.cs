using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;

namespace HomeLibrary.Web.Data;

/// <summary>
/// Создаёт БД (если её нет) и прогоняет скрипты из папки database:
/// схему, хранимые процедуры и демо-данные. Все скрипты идемпотентны.
/// </summary>
public sealed partial class DatabaseInitializer(IConfiguration configuration, ILogger<DatabaseInitializer> logger)
{
    public async Task InitializeAsync(CancellationToken ct = default)
    {
        var builder = new SqlConnectionStringBuilder(configuration.GetConnectionString("HomeLibrary"));
        var databaseName = builder.InitialCatalog;

        builder.InitialCatalog = "master";
        await using (var master = new SqlConnection(builder.ConnectionString))
        {
            await master.OpenAsync(ct);
            await using var create = master.CreateCommand();
            create.CommandText =
                $"""
                IF DB_ID(@name) IS NULL
                    CREATE DATABASE {QuoteName(databaseName)} COLLATE Cyrillic_General_CI_AS;
                """;
            create.Parameters.AddWithValue("@name", databaseName);
            await create.ExecuteNonQueryAsync(ct);
        }

        var scriptsDirectory = Path.Combine(AppContext.BaseDirectory, "database");
        builder.InitialCatalog = databaseName;
        await using var connection = new SqlConnection(builder.ConnectionString);
        await connection.OpenAsync(ct);

        foreach (var file in Directory.GetFiles(scriptsDirectory, "*.sql").Order())
        {
            logger.LogInformation("Выполняю скрипт {Script}", Path.GetFileName(file));
            var script = await File.ReadAllTextAsync(file, ct);

            foreach (var batch in GoSeparator().Split(script).Where(b => !string.IsNullOrWhiteSpace(b)))
            {
                await using var command = connection.CreateCommand();
                command.CommandText = batch;
                await command.ExecuteNonQueryAsync(ct);
            }
        }
    }

    private static string QuoteName(string name) => "[" + name.Replace("]", "]]") + "]";

    // GO — не T-SQL, а разделитель пакетов для sqlcmd/SSMS, поэтому режем скрипт сами
    [GeneratedRegex(@"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase)]
    private static partial Regex GoSeparator();
}
