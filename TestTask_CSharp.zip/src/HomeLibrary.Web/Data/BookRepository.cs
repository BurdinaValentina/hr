using System.Data;
using Dapper;
using HomeLibrary.Web.Models;
using Microsoft.Data.SqlClient;

namespace HomeLibrary.Web.Data;

public sealed class BookRepository(IDbConnectionFactory connectionFactory) : IBookRepository
{
    // Коды пользовательских ошибок, которые бросают процедуры через THROW
    private const int NotFoundError = 50404;
    private const int ConcurrencyError = 50409;

    public async Task<IReadOnlyList<BookListItem>> SearchAsync(BookSearchFilter filter, CancellationToken ct = default)
    {
        await using var connection = await connectionFactory.OpenAsync(ct);

        var rows = await connection.QueryAsync<BookListItem>(new CommandDefinition(
            "dbo.Book_Search",
            new
            {
                filter.Query,
                filter.InTitle,
                filter.InAuthor,
                filter.InToc,
            },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct));

        return rows.AsList();
    }

    public async Task<Book?> GetByIdAsync(int id, CancellationToken ct = default)
    {
        await using var connection = await connectionFactory.OpenAsync(ct);

        return await connection.QuerySingleOrDefaultAsync<Book>(new CommandDefinition(
            "dbo.Book_GetById",
            new { Id = id },
            commandType: CommandType.StoredProcedure,
            cancellationToken: ct));
    }

    public async Task<int> InsertAsync(Book book, CancellationToken ct = default)
    {
        var parameters = CreateBookParameters(book);
        parameters.Add("Id", dbType: DbType.Int32, direction: ParameterDirection.Output);

        await using var connection = await connectionFactory.OpenAsync(ct);
        await connection.ExecuteAsync(new CommandDefinition(
            "dbo.Book_Insert", parameters, commandType: CommandType.StoredProcedure, cancellationToken: ct));

        return parameters.Get<int>("Id");
    }

    public async Task UpdateAsync(Book book, CancellationToken ct = default)
    {
        var parameters = CreateBookParameters(book);
        parameters.Add("Id", book.Id);
        parameters.Add("RowVer", book.RowVer, DbType.Binary, size: 8);

        await using var connection = await connectionFactory.OpenAsync(ct);
        try
        {
            await connection.ExecuteAsync(new CommandDefinition(
                "dbo.Book_Update", parameters, commandType: CommandType.StoredProcedure, cancellationToken: ct));
        }
        catch (SqlException ex) when (ex.Number == NotFoundError)
        {
            throw new BookNotFoundException(book.Id);
        }
        catch (SqlException ex) when (ex.Number == ConcurrencyError)
        {
            throw new BookConcurrencyException(ex.Message);
        }
    }

    public async Task DeleteAsync(int id, CancellationToken ct = default)
    {
        await using var connection = await connectionFactory.OpenAsync(ct);
        try
        {
            await connection.ExecuteAsync(new CommandDefinition(
                "dbo.Book_Delete", new { Id = id }, commandType: CommandType.StoredProcedure, cancellationToken: ct));
        }
        catch (SqlException ex) when (ex.Number == NotFoundError)
        {
            throw new BookNotFoundException(id);
        }
    }

    private static DynamicParameters CreateBookParameters(Book book)
    {
        var parameters = new DynamicParameters();
        parameters.Add("Title", book.Title);
        parameters.Add("Author", book.Author);
        parameters.Add("PublishYear", book.PublishYear);
        parameters.Add("Publisher", book.Publisher);
        parameters.Add("Isbn", book.Isbn, DbType.AnsiString, size: 17);
        parameters.Add("Genre", book.Genre);
        parameters.Add("PageCount", book.PageCount);
        parameters.Add("Location", book.Location);
        parameters.Add("Notes", book.Notes);
        // DbType.Xml -> SqlDbType.Xml: строку проверит и распарсит сам SQL Server
        parameters.Add("TableOfContents", book.TableOfContents, DbType.Xml);
        return parameters;
    }
}
