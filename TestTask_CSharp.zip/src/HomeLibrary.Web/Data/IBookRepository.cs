using HomeLibrary.Web.Models;

namespace HomeLibrary.Web.Data;

/// <summary>Доступ к книгам. Все операции идут через хранимые процедуры dbo.Book_*.</summary>
public interface IBookRepository
{
    Task<IReadOnlyList<BookListItem>> SearchAsync(BookSearchFilter filter, CancellationToken ct = default);

    Task<Book?> GetByIdAsync(int id, CancellationToken ct = default);

    /// <returns>Id созданной книги.</returns>
    Task<int> InsertAsync(Book book, CancellationToken ct = default);

    /// <exception cref="BookNotFoundException"/>
    /// <exception cref="BookConcurrencyException"/>
    Task UpdateAsync(Book book, CancellationToken ct = default);

    /// <exception cref="BookNotFoundException"/>
    Task DeleteAsync(int id, CancellationToken ct = default);
}
