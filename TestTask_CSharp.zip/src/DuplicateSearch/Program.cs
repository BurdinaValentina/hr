using System.Diagnostics;
using DuplicateSearch;

const int n = 100_000_000;

// Массив из N различных чисел (перестановка) — худший случай: дубля нет, проходим до конца
var random = new Random(42);
var m = new int[n];
for (var i = 0; i < n; i++)
    m[i] = i * 3 - 150_000_000;
random.Shuffle(m);

Measure("Без дублей", m);

m[random.Next(n)] = m[random.Next(n)];
Measure("С одним дублем", m);

static void Measure(string title, int[] array)
{
    var sw = Stopwatch.StartNew();
    var result = DuplicateDetector.HasDuplicates(array);
    Console.WriteLine($"{title}: N = {array.Length:N0}, дубли есть = {result}, время = {sw.ElapsedMilliseconds} мс");
}
