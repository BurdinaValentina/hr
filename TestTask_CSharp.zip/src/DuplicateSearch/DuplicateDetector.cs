namespace DuplicateSearch;

/// <summary>
/// Поиск повторяющихся элементов в массиве int за один проход без HashSet.
/// Идея: у int32 всего 2^32 возможных значений, поэтому заводим битовую карту на 2^32 бит (512 МБ).
/// Бит с номером (uint)x означает «значение x уже встречалось».
/// Время O(N), один проход, память — фиксированные 512 МБ независимо от N.
/// </summary>
public static class DuplicateDetector
{
    private const int WordsCount = 1 << 26;  // 2^26 слов * 64 бита = 2^32 бит

    public static bool HasDuplicates(int[] m)
    {
        ArgumentNullException.ThrowIfNull(m);

        var seen = new ulong[WordsCount];

        foreach (var value in m)
        {
            var bit = (uint)value;               // сдвигаем диапазон: int.MinValue -> 0, -1 -> 2^32-1
            var word = bit >> 6;                 // номер 64-битного слова (bit / 64)
            var mask = 1UL << (int)(bit & 63);   // позиция бита внутри слова (bit % 64)

            if ((seen[word] & mask) != 0)
                return true;                     // бит уже стоит — значение встречалось

            seen[word] |= mask;
        }

        return false;
    }
}
