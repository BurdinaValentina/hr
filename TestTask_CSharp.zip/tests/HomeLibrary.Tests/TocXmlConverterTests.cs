using System.Text;
using System.Xml.Linq;
using HomeLibrary.Web.Services;

namespace HomeLibrary.Tests;

public class TocXmlConverterTests
{
    private readonly TocXmlConverter _converter = new();

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("<p><br></p>")]
    [InlineData("<p>&nbsp;</p>")]
    public void HtmlToXml_EmptyContent_ReturnsNull(string? html)
    {
        Assert.Null(_converter.HtmlToXml(html));
    }

    [Fact]
    public void HtmlToXml_ProducesWellFormedXmlWithTocRoot()
    {
        var xml = _converter.HtmlToXml("<h2>Часть 1</h2><ol><li>Глава 1<br>подзаголовок</li><li>Глава 2</li></ol>");

        var root = XElement.Parse(xml!);
        Assert.Equal("toc", root.Name.LocalName);
        Assert.Equal(2, root.Descendants("li").Count());
        Assert.Contains("<br />", xml);
    }

    [Fact]
    public void HtmlToXml_RemovesDangerousMarkup()
    {
        var xml = _converter.HtmlToXml(
            "<p onclick=\"alert(1)\">Глава<script>alert(1)</script></p><img src=x onerror=alert(1)><a href=\"javascript:alert(1)\">ссылка</a>");

        Assert.DoesNotContain("script", xml);
        Assert.DoesNotContain("onclick", xml);
        Assert.DoesNotContain("onerror", xml);
        Assert.DoesNotContain("javascript", xml);
        Assert.Contains("Глава", xml);
    }

    [Fact]
    public void HtmlToXml_EscapesSpecialCharactersAndNbsp()
    {
        var xml = _converter.HtmlToXml("<p>Цена &lt; 500&nbsp;000 руб. &amp; R&amp;D</p>");

        var root = XElement.Parse(xml!);
        Assert.Equal("Цена < 500 000 руб. & R&D", root.Value);
    }

    [Fact]
    public void RoundTrip_HtmlToXmlToHtml_KeepsStructure()
    {
        const string html = "<h2>Часть I</h2><ol><li>Основы</li><li>Типы</li></ol>";

        var restored = _converter.XmlToHtml(_converter.HtmlToXml(html));

        Assert.Equal(html, restored);
    }

    [Fact]
    public void XmlFile_ExportThenImport_ReturnsSameContent()
    {
        var xml = _converter.HtmlToXml("<h2>Часть I</h2><ul><li>Глава 1</li></ul>");

        var file = Encoding.UTF8.GetString(_converter.ToXmlFile(xml, "Книга", "Автор"));
        var html = _converter.ImportXmlFile(file);

        Assert.StartsWith("<?xml", file);
        Assert.Contains("title=\"Книга\"", file);
        Assert.Equal("<h2>Часть I</h2><ul><li>Глава 1</li></ul>", html);
    }

    [Theory]
    [InlineData("не xml")]
    [InlineData("<toc><p>незакрытый</toc>")]
    [InlineData("<chapters><p>Глава</p></chapters>")]
    public void ImportXmlFile_InvalidFile_Throws(string content)
    {
        Assert.Throws<TocFormatException>(() => _converter.ImportXmlFile(content));
    }
}
