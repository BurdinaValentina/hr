using DuplicateSearch;

namespace HomeLibrary.Tests;

public class DuplicateDetectorTests
{
    [Theory]
    [InlineData(new int[0], false)]
    [InlineData(new[] { 7 }, false)]
    [InlineData(new[] { 1, 2, 3, 4 }, false)]
    [InlineData(new[] { 1, 2, 3, 1 }, true)]
    [InlineData(new[] { -1, 0, 1, -1 }, true)]
    [InlineData(new[] { int.MinValue, int.MaxValue, 0, -1 }, false)]
    [InlineData(new[] { int.MaxValue, 5, int.MaxValue }, true)]
    [InlineData(new[] { int.MinValue, int.MinValue }, true)]
    public void HasDuplicates_DetectsRepeats(int[] m, bool expected)
    {
        Assert.Equal(expected, DuplicateDetector.HasDuplicates(m));
    }

    [Fact]
    public void HasDuplicates_ValuesFromSameWordButDifferentBits_AreDistinct()
    {
        // 0..63 попадают в одно 64-битное слово — проверяем, что биты не путаются
        Assert.False(DuplicateDetector.HasDuplicates(Enumerable.Range(0, 64).ToArray()));
    }
}
