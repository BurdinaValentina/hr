/*
    Домашняя библиотека — схема БД.
    Скрипт идемпотентный: его можно запускать повторно.
*/
IF OBJECT_ID(N'dbo.Book', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Book
    (
        Id              int IDENTITY(1, 1) NOT NULL,
        Title           nvarchar(300)      NOT NULL,
        Author          nvarchar(300)      NOT NULL,
        PublishYear     smallint           NULL,
        Publisher       nvarchar(200)      NULL,
        Isbn            varchar(17)        NULL,
        Genre           nvarchar(100)      NULL,
        PageCount       int                NULL,
        Location        nvarchar(100)      NULL,  -- где стоит книга: шкаф / полка
        Notes           nvarchar(2000)     NULL,
        TableOfContents xml                NULL,  -- оглавление: <toc>…XHTML…</toc>
        CreatedAt       datetime2(0)       NOT NULL CONSTRAINT DF_Book_CreatedAt DEFAULT (SYSUTCDATETIME()),
        UpdatedAt       datetime2(0)       NOT NULL CONSTRAINT DF_Book_UpdatedAt DEFAULT (SYSUTCDATETIME()),
        RowVer          rowversion         NOT NULL,  -- для оптимистичной блокировки при редактировании

        CONSTRAINT PK_Book PRIMARY KEY CLUSTERED (Id),
        CONSTRAINT CK_Book_Title       CHECK (LEN(Title) > 0),
        CONSTRAINT CK_Book_Author      CHECK (LEN(Author) > 0),
        CONSTRAINT CK_Book_PublishYear CHECK (PublishYear BETWEEN 1400 AND 2100),
        CONSTRAINT CK_Book_PageCount   CHECK (PageCount > 0)
    );

    CREATE INDEX IX_Book_Title  ON dbo.Book (Title);
    CREATE INDEX IX_Book_Author ON dbo.Book (Author);

    -- Первичный XML-индекс ускоряет exist()/nodes() при поиске по оглавлению
    CREATE PRIMARY XML INDEX PXML_Book_TableOfContents ON dbo.Book (TableOfContents);
END
GO
