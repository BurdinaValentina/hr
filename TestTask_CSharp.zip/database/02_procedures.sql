/*
    Домашняя библиотека — хранимые процедуры (CRUD + поиск).
    Коды ошибок:
        50404 — книга не найдена
        50409 — запись изменена другим пользователем (конфликт версий)
*/

CREATE OR ALTER PROCEDURE dbo.Book_Search
    @Query    nvarchar(200) = NULL,  -- строка поиска; NULL/пусто — вернуть все книги
    @InTitle  bit = 1,
    @InAuthor bit = 1,
    @InToc    bit = 1
AS
BEGIN
    SET NOCOUNT ON;

    SET @Query = NULLIF(LTRIM(RTRIM(@Query)), N'');

    -- Экранируем спецсимволы LIKE, чтобы «50%» или «C_Sharp» искались буквально
    DECLARE @Pattern nvarchar(450) =
        N'%' + REPLACE(REPLACE(REPLACE(@Query, N'[', N'[[]'), N'%', N'[%]'), N'_', N'[_]') + N'%';

    -- В XQuery contains() регистрозависим, поэтому сравниваем в верхнем регистре
    DECLARE @QueryUpper nvarchar(200) = UPPER(@Query);

    SELECT
        b.Id,
        b.Title,
        b.Author,
        b.PublishYear,
        b.Genre,
        b.Location,
        CAST(CASE WHEN b.TableOfContents IS NULL THEN 0 ELSE 1 END AS bit) AS HasToc
    FROM dbo.Book AS b
    WHERE @Query IS NULL
       OR (@InTitle  = 1 AND b.Title  LIKE @Pattern)
       OR (@InAuthor = 1 AND b.Author LIKE @Pattern)
       OR (@InToc    = 1 AND b.TableOfContents.exist(
               N'//text()[contains(upper-case(.), sql:variable("@QueryUpper"))]') = 1)
    ORDER BY b.Author, b.Title
    OPTION (RECOMPILE);  -- «catch-all» запрос: план строим под фактические параметры
END
GO

CREATE OR ALTER PROCEDURE dbo.Book_GetById
    @Id int
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        Id, Title, Author, PublishYear, Publisher, Isbn, Genre, PageCount, Location, Notes,
        CAST(TableOfContents AS nvarchar(max)) AS TableOfContents,
        CreatedAt, UpdatedAt, RowVer
    FROM dbo.Book
    WHERE Id = @Id;
END
GO

CREATE OR ALTER PROCEDURE dbo.Book_Insert
    @Title           nvarchar(300),
    @Author          nvarchar(300),
    @PublishYear     smallint       = NULL,
    @Publisher       nvarchar(200)  = NULL,
    @Isbn            varchar(17)    = NULL,
    @Genre           nvarchar(100)  = NULL,
    @PageCount       int            = NULL,
    @Location        nvarchar(100)  = NULL,
    @Notes           nvarchar(2000) = NULL,
    @TableOfContents xml            = NULL,
    @Id              int OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    INSERT dbo.Book (Title, Author, PublishYear, Publisher, Isbn, Genre, PageCount, Location, Notes, TableOfContents)
    VALUES (@Title, @Author, @PublishYear, @Publisher, @Isbn, @Genre, @PageCount, @Location, @Notes, @TableOfContents);

    SET @Id = SCOPE_IDENTITY();
END
GO

CREATE OR ALTER PROCEDURE dbo.Book_Update
    @Id              int,
    @Title           nvarchar(300),
    @Author          nvarchar(300),
    @PublishYear     smallint       = NULL,
    @Publisher       nvarchar(200)  = NULL,
    @Isbn            varchar(17)    = NULL,
    @Genre           nvarchar(100)  = NULL,
    @PageCount       int            = NULL,
    @Location        nvarchar(100)  = NULL,
    @Notes           nvarchar(2000) = NULL,
    @TableOfContents xml            = NULL,
    @RowVer          binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    UPDATE dbo.Book
    SET Title           = @Title,
        Author          = @Author,
        PublishYear     = @PublishYear,
        Publisher       = @Publisher,
        Isbn            = @Isbn,
        Genre           = @Genre,
        PageCount       = @PageCount,
        Location        = @Location,
        Notes           = @Notes,
        TableOfContents = @TableOfContents,
        UpdatedAt       = SYSUTCDATETIME()
    WHERE Id = @Id
      AND RowVer = @RowVer;

    IF @@ROWCOUNT = 0
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Book WHERE Id = @Id)
            THROW 50404, N'Книга не найдена', 1;

        THROW 50409, N'Книга была изменена другим пользователем. Обновите карточку и повторите правку.', 1;
    END
END
GO

CREATE OR ALTER PROCEDURE dbo.Book_Delete
    @Id int
AS
BEGIN
    SET NOCOUNT ON;

    DELETE dbo.Book WHERE Id = @Id;

    IF @@ROWCOUNT = 0
        THROW 50404, N'Книга не найдена', 1;
END
GO
